import SwiftUI
import UIKit

// MARK: - License Management Models
struct LicenseModel: Codable, Identifiable {
    let id: UUID?
    let key: String
    let owner: String
    let deviceId: String?
    let expiresAt: String?
    let isAdmin: Bool

    enum CodingKeys: String, CodingKey {
        case id
        case key
        case owner
        case deviceId = "device_id"
        case expiresAt = "expires_at"
        case isAdmin = "is_admin"
    }
}

// MARK: - Supabase Service cho Shinn Cheat
final class SupabaseKeyManagerService {
    static let shared = SupabaseKeyManagerService()
    
    // Cấu hình thông tin Supabase của bạn
    private let supabaseURL = URL(string: "https://xxnzfkucpzqwrrgxlldn.supabase.co/rest/v1/")!
    private let apiKey = "sb_publishable_kC0H0YA4CEEJtrdqnUvYIw_X6Qwd8Gj"
    
    // Xác thực key đăng nhập
    func verifyKey(key: String, deviceId: String) async -> Result<(owner: String, remaining: String, isAdmin: Bool), Error> {
        // Kiểm tra nhanh quyền Admin đặc biệt bằng code cứng hoặc check trên DB
        if key == "Shinn-Cheat-Ower" {
            return .success(("Shinn Admin", "Lifetime (Admin)", true))
        }
        
        // Gọi Supabase REST API để kiểm tra key thông thường
        do {
            var urlComponents = URLComponents(url: supabaseURL.appendingPathComponent("licenses"), resolvingAgainstBaseURL: true)!
            urlComponents.queryItems = [URLQueryItem(name: "key", value: "eq.\(key)")]
            
            var request = URLRequest(url: urlComponents.url!)
            request.httpMethod = "GET"
            request.setValue(apiKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
            
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                return .failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Server error."]))
            }
            
            let licenses = try JSONDecoder().decode([LicenseModel].self, from: data)
            guard let license = licenses.first else {
                return .failure(NSError(domain: "", code: -2, userInfo: [NSLocalizedDescriptionKey: "Invalid or expired license key."]))
            }
            
            // Kiểm tra ràng buộc Device ID (Nếu đã gán máy khác thì từ chối)
            if let boundDevice = license.deviceId, !boundDevice.isEmpty, boundDevice != deviceId {
                return .failure(NSError(domain: "", code: -3, userInfo: [NSLocalizedDescriptionKey: "This key is already bound to another device."]))
            }
            
            // Nếu chưa gán thiết bị, tự động cập nhật gán thiết bị này vào DB
            if license.deviceId == nil || license.deviceId?.isEmpty == true {
                await updateDeviceID(for: key, deviceId: deviceId)
            }
            
            return .success((license.owner, license.expiresAt ?? "Unlimited", license.isAdmin))
        } catch {
            return .failure(error)
        }
    }
    
    // Lấy toàn bộ danh sách key (Dành riêng cho Admin)
    func fetchAllLicenses() async -> [LicenseModel] {
        do {
            var request = URLRequest(url: supabaseURL.appendingPathComponent("licenses"))
            request.httpMethod = "GET"
            request.setValue(apiKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
            
            let (data, _) = try await URLSession.shared.data(for: request)
            return (try? JSONDecoder().decode([LicenseModel].self, from: data)) ?? []
        } catch {
            return []
        }
    }
    
    // Tạo key mới (Dành cho Admin)
    func createLicense(key: String, owner: String, expiresAt: String, isAdmin: Bool) async -> Bool {
        do {
            var request = URLRequest(url: supabaseURL.appendingPathComponent("licenses"))
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(apiKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
            request.setValue("return=representation", forHTTPHeaderField: "Prefer")
            
            let body: [String: Any] = [
                "key": key,
                "owner": owner,
                "expires_at": expiresAt,
                "is_admin": isAdmin
            ]
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            
            let (_, response) = try await URLSession.shared.data(for: request)
            return (response as? HTTPURLResponse)?.statusCode == 201
        } catch {
            return false
        }
    }
    
    // Xóa key (Dành cho Admin)
    func deleteLicense(keyID: String) async -> Bool {
        do {
            var urlComponents = URLComponents(url: supabaseURL.appendingPathComponent("licenses"), resolvingAgainstBaseURL: true)!
            urlComponents.queryItems = [URLQueryItem(name: "key", value: "eq.\(keyID)")]
            
            var request = URLRequest(url: urlComponents.url!)
            request.httpMethod = "DELETE"
            request.setValue(apiKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
            
            let (_, response) = try await URLSession.shared.data(for: request)
            return (200..<300).contains((response as? HTTPURLResponse)?.statusCode ?? 0)
        } catch {
            return false
        }
    }
    
    private func updateDeviceID(for key: String, deviceId: String) async {
        var urlComponents = URLComponents(url: supabaseURL.appendingPathComponent("licenses"), resolvingAgainstBaseURL: true)!
        urlComponents.queryItems = [URLQueryItem(name: "key", value: "eq.\(key)")]
        
        var request = URLRequest(url: urlComponents.url!)
        request.httpMethod = "PATCH"
        request.setValue("application/json", forHTTPHeaderField: "Type")
        request.setValue(apiKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        
        let body = ["device_id": deviceId]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        _ = try? await URLSession.shared.data(for: request)
    }
}

// MARK: - Session Mở rộng cho Admin
final class Session: ObservableObject {
    @Published var isVerified: Bool = false
    @Published var ownerName: String = ""
    @Published var remainingTime: String = ""
    @Published var isAdmin: Bool = false
}

// MARK: - Admin Key Manager View (Giao diện quản lý key trực tiếp trong app)
struct AdminKeyManagerView: View {
    @State private var licenses: [LicenseModel] = []
    @State private var showingAddKeySheet = false
    @State private var isLoading = false

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()
            
            VStack {
                List {
                    Section(header: Text("Manager Keys (\(licenses.count))")) {
                        ForEach(licenses) { license in
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text(license.key)
                                        .font(.system(size: 15, weight: .bold, design: .monospaced))
                                    Spacer()
                                    if license.isAdmin {
                                        Text("ADMIN")
                                            .font(.caption2.bold())
                                            .padding(.horizontal, 6)
                                            .padding(.vertical, 2)
                                            .background(Color.purple.opacity(0.2))
                                            .foregroundColor(.purple)
                                            .cornerRadius(4)
                                    }
                                }
                                Text("Owner: \(license.owner)")
                                    .font(.subheadline)
                                Text("Expires: \(license.expiresAt ?? "N/A")")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            .padding(.vertical, 4)
                        }
                        .onDelete(perform: deleteKeys)
                    }
                }
                .listStyle(.insetGrouped)
            }
        }
        .navigationTitle("Admin Key Panel")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: { showingAddKeySheet = true }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title3)
                }
            }
        }
        .sheet(isPresented: $showingAddKeySheet, onDismiss: { loadData() }) {
            AddKeyModalView()
        }
        .task {
            loadData()
        }
    }

    private func loadData() {
        Task {
            licenses = await SupabaseKeyManagerService.shared.fetchAllLicenses()
        }
    }

    private func deleteKeys(at offsets: IndexSet) {
        for index in offsets {
            let license = licenses[index]
            Task {
                _ = await SupabaseKeyManagerService.shared.deleteLicense(keyID: license.key)
                loadData()
            }
        }
    }
}

// MARK: - Modal Thêm Key Mới Cho Admin
struct AddKeyModalView: View {
    @Environment(\.dismiss) var dismiss
    @State private var keyText = ""
    @State private var ownerText = ""
    @State private var expiresText = "30 Days"
    @State private var isAdminKey = false

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("New License Info")) {
                    TextField("License Key (e.g. VIP-XYZ)", text: $keyText)
                    TextField("Owner Name", text: $ownerText)
                    TextField("Expires (e.g. 30 Days / Lifetime)", text: $expiresText)
                    Toggle("Is Admin Key?", isOn: $isAdminKey)
                }
            }
            .navigationTitle("Create New Key")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        Task {
                            _ = await SupabaseKeyManagerService.shared.createLicense(
                                key: keyText,
                                owner: ownerText,
                                expiresAt: expiresText,
                                isAdmin: isAdminKey
                            )
                            dismiss()
                        }
                    }
                    .disabled(keyText.isEmpty || ownerText.isEmpty)
                }
            }
        }
    }
}
