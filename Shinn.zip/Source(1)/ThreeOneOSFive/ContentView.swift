============================================================
// SHINN CHEAT 
// ============================================================
// Tích hợp vào source hiện tại.
//
// Supabase:
// URL: https://xxnzfkucpzqwrrgxlldn.supabase.co
//
// Bảng public.keys cần có:
// key          text
// name         text
// expires_at   timestamptz
// role         text (không bắt buộc cho phần này)
// used         boolean (không bắt buộc cho phần này)
//
// QUAN TRỌNG:
// - Không dùng service_role trong app.
// - Publishable key đặt trong app.
// - App chỉ SELECT đúng Key được nhập.
// - Không force unwrap JSON/API.
// - Không exit(0) khi API lỗi.
// ============================================================

import SwiftUI
import Foundation
import CryptoKit
import UIKit

// MARK: - Supabase configuration

enum ShinnSupabaseConfig {
    static let projectURL = URL(
        string: "https://xxnzfkucpzqwrrgxlldn.supabase.co"
    )!

    static let publishableKey =
        "sb_publishable_kC0H0YA4CEEJtrdqnUvYIw_X6Qwd8Gj"

    static let keysEndpoint = projectURL
        .appendingPathComponent("rest")
        .appendingPathComponent("v1")
        .appendingPathComponent("keys")
}

// MARK: - Key model

struct ShinnKeyRecord: Decodable {
    let key: String
    let name: String?
    let expiresAt: String?
    let role: String?
    let used: Bool?
    let deviceID: String?
    let maxDevices: Int?

    enum CodingKeys: String, CodingKey {
        case key
        case name
        case expiresAt = "expires_at"
        case role
        case used
        case deviceID = "device_id"
        case maxDevices = "max_devices"
    }

    var displayName: String {
        let value = (name ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        return value.isEmpty ? "Người dùng" : value
    }

    var expirationDate: Date? {
        guard let expiresAt, !expiresAt.isEmpty else {
            return nil
        }

        return ShinnDateParser.parse(expiresAt)
    }
}

// MARK: - Date parser

enum ShinnDateParser {
    static func parse(_ value: String) -> Date? {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [
            .withInternetDateTime,
            .withFractionalSeconds
        ]

        if let date = iso.date(from: value) {
            return date
        }

        iso.formatOptions = [
            .withInternetDateTime
        ]

        if let date = iso.date(from: value) {
            return date
        }

        let formats = [
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXXXX",
            "yyyy-MM-dd'T'HH:mm:ssXXXXX",
            "yyyy-MM-dd HH:mm:ssXXXXX"
        ]

        for format in formats {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.dateFormat = format

            if let date = formatter.date(from: value) {
                return date
            }
        }

        return nil
    }
}

// MARK: - Key auth errors

enum ShinnKeyAuthError: LocalizedError {
    case invalidKey
    case expired
    case invalidServerResponse
    case server(Int)
    case network(String)
    case invalidData
    case missingExpiration
    case missingName

    var errorDescription: String? {
        switch self {
        case .invalidKey:
            return "Key không tồn tại hoặc không hợp lệ."

        case .expired:
            return "Key đã hết hạn."

        case .invalidServerResponse:
            return "Phản hồi từ máy chủ không hợp lệ."

        case .server(let code):
            return "Máy chủ trả về lỗi HTTP \(code)."

        case .network(let message):
            return "Không thể kết nối máy chủ: \(message)"

        case .invalidData:
            return "Dữ liệu Key từ máy chủ không hợp lệ."

        case .missingExpiration:
            return "Key chưa được cấu hình thời gian hết hạn."

        case .missingName:
            return "Key chưa được cấu hình tên người sử dụng."
        }
    }
}

// MARK: - Key session

@MainActor
final class ShinnKeySession: ObservableObject {

    @Published private(set) var isLoading = false
    @Published private(set) var isAuthenticated = false
    @Published private(set) var record: ShinnKeyRecord?
    @Published var errorMessage: String?

    @Published private(set) var remainingText = ""

    private var countdownTask: Task<Void, Never>?

    init() {
        restoreSavedSession()
    }

    deinit {
        countdownTask?.cancel()
    }

    var userName: String {
        record?.displayName ?? "Người dùng"
    }

    var key: String {
        record?.key ?? ""
    }

    var roleName: String {
        let value = record?.role?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

        return value.isEmpty ? "Member" : value
    }

    func login(key input: String) async {
        let cleanedKey = input
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard !cleanedKey.isEmpty else {
            errorMessage = "Vui lòng nhập Key."
            return
        }

        isLoading = true
        errorMessage = nil
        countdownTask?.cancel()

        do {
            let result = try await ShinnKeyAPI.shared.validate(
                key: cleanedKey
            )

            guard let expiration = result.expirationDate else {
                throw ShinnKeyAuthError.missingExpiration
            }

            guard expiration > Date() else {
                throw ShinnKeyAuthError.expired
            }

            guard !result.displayName.isEmpty else {
                throw ShinnKeyAuthError.missingName
            }

            record = result
            isAuthenticated = true
            remainingText = Self.remainingText(to: expiration)

            saveSession(key: cleanedKey)

            startCountdown(to: expiration)

        } catch {
            isAuthenticated = false
            record = nil
            remainingText = ""

            if let authError = error as? ShinnKeyAuthError {
                errorMessage = authError.localizedDescription
            } else {
                errorMessage = error.localizedDescription
            }
        }

        isLoading = false
    }

    func logout() {
        countdownTask?.cancel()
        countdownTask = nil

        record = nil
        isAuthenticated = false
        remainingText = ""
        errorMessage = nil

        UserDefaults.standard.removeObject(
            forKey: "ShinnCheat.savedKey"
        )
    }

    private func startCountdown(to expiration: Date) {
        countdownTask?.cancel()

        countdownTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                guard let self else { return }

                let now = Date()

                if now >= expiration {
                    self.isAuthenticated = false
                    self.record = nil
                    self.remainingText = ""
                    self.errorMessage = "Key đã hết hạn."

                    UserDefaults.standard.removeObject(
                        forKey: "ShinnCheat.savedKey"
                    )

                    return
                }

                self.remainingText =
                    Self.remainingText(to: expiration)

                try? await Task.sleep(
                    nanoseconds: 1_000_000_000
                )
            }
        }
    }

    private func saveSession(key: String) {
        UserDefaults.standard.set(
            key,
            forKey: "ShinnCheat.savedKey"
        )
    }

    private func restoreSavedSession() {
        guard let savedKey = UserDefaults.standard.string(
            forKey: "ShinnCheat.savedKey"
        ), !savedKey.isEmpty else {
            return
        }

        Task { @MainActor [weak self] in
            await self?.login(key: savedKey)
        }
    }

    static func remainingText(to date: Date) -> String {
        let seconds = max(
            0,
            Int(date.timeIntervalSinceNow)
        )

        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        let secs = seconds % 60

        if days > 0 {
            return "\(days) ngày \(hours) giờ \(minutes) phút"
        }

        if hours > 0 {
            return "\(hours) giờ \(minutes) phút \(secs) giây"
        }

        if minutes > 0 {
            return "\(minutes) phút \(secs) giây"
        }

        return "\(secs) giây"
    }
}

// MARK: - Supabase REST API

final class ShinnKeyAPI {

    static let shared = ShinnKeyAPI()

    private init() {}

    func validate(key: String) async throws -> ShinnKeyRecord {
        var components = URLComponents(
            url: ShinnSupabaseConfig.keysEndpoint,
            resolvingAgainstBaseURL: false
        )

        components?.queryItems = [
            URLQueryItem(
                name: "select",
                value: "key,name,expires_at,role,used,device_id,max_devices"
            ),
            URLQueryItem(
                name: "key",
                value: "eq.\(key)"
            ),
            URLQueryItem(
                name: "limit",
                value: "1"
            )
        ]

        guard let url = components?.url else {
            throw ShinnKeyAuthError.invalidServerResponse
        }

        var request = URLRequest(
            url: url,
            cachePolicy: .reloadIgnoringLocalCacheData,
            timeoutInterval: 20
        )

        request.httpMethod = "GET"

        request.setValue(
            ShinnSupabaseConfig.publishableKey,
            forHTTPHeaderField: "apikey"
        )

        request.setValue(
            "Bearer \(ShinnSupabaseConfig.publishableKey)",
            forHTTPHeaderField: "Authorization"
        )

        request.setValue(
            "application/json",
            forHTTPHeaderField: "Accept"
        )

        let data: Data
        let response: URLResponse

        do {
            (data, response) = try await URLSession.shared.data(
                for: request
            )
        } catch {
            throw ShinnKeyAuthError.network(
                error.localizedDescription
            )
        }

        guard let http = response as? HTTPURLResponse else {
            throw ShinnKeyAuthError.invalidServerResponse
        }

        guard (200..<300).contains(http.statusCode) else {
            throw ShinnKeyAuthError.server(
                http.statusCode
            )
        }

        guard !data.isEmpty else {
            throw ShinnKeyAuthError.invalidKey
        }

        let records: [ShinnKeyRecord]

        do {
            records = try JSONDecoder().decode(
                [ShinnKeyRecord].self,
                from: data
            )
        } catch {
            throw ShinnKeyAuthError.invalidData
        }

        guard let record = records.first else {
            throw ShinnKeyAuthError.invalidKey
        }

        return record
    }
}

// MARK: - Key Gate UI

struct ShinnKeyGateView: View {

    @EnvironmentObject var keySession: ShinnKeySession

    @State private var keyInput = ""
    @FocusState private var focused: Bool

    var body: some View {
        ZStack {
            BackgroundView()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {

                    Spacer(minLength: 40)

                    Image(systemName: "key.fill")
                        .font(.system(size: 48, weight: .bold))

                    VStack(spacing: 6) {
                        Text("SHINN CHEAT")
                            .font(
                                .system(
                                    size: 32,
                                    weight: .black,
                                    design: .rounded
                                )
                            )

                        Text("Nhập Key để tiếp tục")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 12) {

                        Label(
                            "Key truy cập",
                            systemImage: "key.horizontal.fill"
                        )
                        .font(.headline)

                        TextField(
                            "Nhập Key của bạn",
                            text: $keyInput
                        )
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                        .focused($focused)
                        .padding(15)
                        .background(
                            Color.primary.opacity(0.08),
                            in: RoundedRectangle(
                                cornerRadius: 15,
                                style: .continuous
                            )
                        )
                        .submitLabel(.go)
                        .onSubmit {
                            submit()
                        }

                        if let error = keySession.errorMessage {
                            Label(
                                error,
                                systemImage: "exclamationmark.triangle.fill"
                            )
                            .font(.footnote)
                            .foregroundStyle(.red)
                            .fixedSize(
                                horizontal: false,
                                vertical: true
                            )
                        }

                        Button(action: submit) {
                            HStack {
                                if keySession.isLoading {
                                    ProgressView()
                                        .tint(
                                            Color(.systemBackground)
                                        )
                                } else {
                                    Image(
                                        systemName: "arrow.right.circle.fill"
                                    )
                                }

                                Text(
                                    keySession.isLoading
                                    ? "Đang kiểm tra..."
                                    : "Xác nhận Key"
                                )
                                .fontWeight(.bold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(
                                Color.primary,
                                in: RoundedRectangle(
                                    cornerRadius: 15,
                                    style: .continuous
                                )
                            )
                            .foregroundStyle(
                                Color(.systemBackground)
                            )
                        }
                        .buttonStyle(.plain)
                        .disabled(
                            keySession.isLoading ||
                            keyInput.trimmingCharacters(
                                in: .whitespacesAndNewlines
                            ).isEmpty
                        )
                    }
                    .padding(18)
                    .shinnGlass()

                    Spacer(minLength: 30)
                }
                .padding(.horizontal, 20)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .onTapGesture {
            focused = false
        }
    }

    private func submit() {
        focused = false

        let value = keyInput
            .trimmingCharacters(
                in: .whitespacesAndNewlines
            )

        guard !value.isEmpty else {
            return
        }

        Task {
            await keySession.login(key: value)
        }
    }
}

// MARK: - Key information card
// Có thể đặt card này trong HomeView nếu muốn hiện tên/thời gian ngay trên Home.

struct ShinnKeyInfoCard: View {

    @EnvironmentObject var keySession: ShinnKeySession

    var body: some View {
        if keySession.isAuthenticated,
           let record = keySession.record {

            VStack(alignment: .leading, spacing: 12) {

                HStack(spacing: 12) {
                    Image(systemName: "person.crop.circle.fill")
                        .font(.system(size: 32))

                    VStack(alignment: .leading, spacing: 3) {
                        Text("Xin chào, \(record.displayName) 👋")
                            .font(.headline.bold())

                        Text(
                            record.role?
                                .isEmpty == false
                            ? record.role!.uppercased()
                            : "MEMBER"
                        )
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)
                    }

                    Spacer()
                }

                Divider()

                HStack {
                    Label(
                        "Thời gian còn lại",
                        systemImage: "clock.fill"
                    )

                    Spacer()

                    Text(keySession.remainingText)
                        .font(.caption.bold())
                        .multilineTextAlignment(.trailing)
                }
            }
            .padding(16)
            .shinnGlass()
        }
    }
}


// ============================================================
// THAY THẾ PHẦN APP ROOT HIỆN TẠI
// ============================================================
//
// Xóa ContentView hiện tại:
//
// struct ContentView: View {
//     @StateObject private var session = Session()
//     ...
// }
//
// rồi dùng ContentView bên dưới.
// ============================================================

struct ContentView: View {

    @StateObject private var session = Session()
    @StateObject private var keySession = ShinnKeySession()

    @State private var path: [Route] = []

    var body: some View {
        Group {
            if !keySession.isAuthenticated {

                ShinnKeyGateView()

            } else if session.role == nil {

                RoleGateView()

            } else {

                NavigationStack(path: $path) {
                    HomeView(
                        open: { route in
                            path.append(route)
                        }
                    )
                    .navigationDestination(
                        for: Route.self
                    ) { route in

                        switch route {

                        case .packages(let category):
                            PackagesView(
                                initialCategory: category
                            )

                        case .detail(let id):
                            PackageDetailView(
                                packageID: id
                            )

                        case .settings:
                            SettingsView()

                        case .about:
                            AboutView()

                        case .support:
                            SupportView()
                        }
                    }
                }
                .tint(.primary)
            }
        }
        .environmentObject(session)
        .environmentObject(keySession)
        .animation(
            .easeInOut(duration: 0.25),
            value: keySession.isAuthenticated
        )
        .animation(
            .easeInOut(duration: 0.25),
            value: session.role
        )
    }
}


// ============================================================
// THÊM CARD KEY VÀO HOME
// ============================================================
//
// Trong HomeView hiện tại, tìm:
//
// LazyVStack(spacing: 14) {
//     header
//     hero
//
// Thay thành:
//
// LazyVStack(spacing: 14) {
//     header
//     hero
//     ShinnKeyInfoCard()
//     sectionTitle
//
// HomeView đã có @EnvironmentObject session/store/settings,
// nhưng cần thêm:
//
// @EnvironmentObject var keySession: ShinnKeySession
//
// vào HomeView nếu dùng card trực tiếp.
//
// ============================================================
