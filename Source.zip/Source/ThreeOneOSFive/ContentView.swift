import Foundation
import SwiftUI
import UIKit

enum SupabaseConfig {
    static let projectURL = URL(string: "https://xxnzfkucpzqwrrgxlldn.supabase.co")!
    static let anonKey = "sb_publishable_kC0H0YA4CEEJtrdqnUvYIw_X6Qwd8Gj"
}

struct ActivateKeyResponse: Decodable {
    let ok: Bool
    let error: String?
    let role: String?
    let key: String?
}

@MainActor
final class LicenseManager: ObservableObject {
    @Published var isActivated: Bool
    @Published var isBusy = false
    @Published var lastError: String?
    @Published var boundRole: String?

    private let activatedKey = "shinn.license.activated"
    private let roleKey = "shinn.license.role"
    private let deviceKey = "shinn.license.device_id"

    init() {
        let defaults = UserDefaults.standard
        isActivated = defaults.bool(forKey: activatedKey)
        boundRole = defaults.string(forKey: roleKey)
    }

    var deviceID: String {
        let defaults = UserDefaults.standard
        if let existing = defaults.string(forKey: deviceKey), !existing.isEmpty {
            return existing
        }
        let generated = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        defaults.set(generated, forKey: deviceKey)
        return generated
    }

    func activate(key raw: String, language: ShinnLanguage) async -> Bool {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        lastError = nil

        guard !key.isEmpty else {
            lastError = language == .vi ? "Nhập key kích hoạt." : "Enter an activation key."
            return false
        }

        isBusy = true
        defer { isBusy = false }

        do {
            let result = try await callActivate(key: key)
            if result.ok {
                UserDefaults.standard.set(true, forKey: activatedKey)
                if let role = result.role, !role.isEmpty {
                    UserDefaults.standard.set(role, forKey: roleKey)
                    boundRole = role
                }
                isActivated = true
                return true
            }
            lastError = mappedError(result.error, language: language)
            return false
        } catch {
            lastError = language == .vi
                ? "Không kết nối được máy chủ key. Kiểm tra mạng."
                : "Could not reach the key server. Check your connection."
            return false
        }
    }

    func signOutLicense() {
        let defaults = UserDefaults.standard
        defaults.set(false, forKey: activatedKey)
        defaults.removeObject(forKey: roleKey)

        isActivated = false
        boundRole = nil
    }

    private func mappedError(_ code: String?, language: ShinnLanguage) -> String {
        let vi = language == .vi
        switch code {
        case "invalid_key":
            return vi ? "Key không hợp lệ." : "Invalid key."
        case "used_on_other_device":
            return vi ? "Key đã được dùng trên máy khác." : "This key is already used on another device."
        case "missing_key":
            return vi ? "Thiếu key." : "Missing key."
        case "missing_device":
            return vi ? "Thiếu mã thiết bị." : "Missing device id."
        default:
            return vi ? "Không kích hoạt được key." : "Could not activate the key."
        }
    }

    private func callActivate(key: String) async throws -> ActivateKeyResponse {
        var request = URLRequest(
            url: SupabaseConfig.projectURL.appendingPathComponent("/rest/v1/rpc/activate_key")
        )
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")

        let body: [String: String] = [
            "p_key": key,
            "p_device_id": deviceID
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode(ActivateKeyResponse.self, from: data)
    }
}

struct ActivateKeyView: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var session: Session
    @EnvironmentObject var license: LicenseManager

    @State private var keyText = ""
    @FocusState private var focused: Bool

    private var isVI: Bool { settings.language == .vi }

    var body: some View {
        ZStack {
            BackgroundView()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 22) {
                    VStack(spacing: 22) {
                        Image(systemName: "key.fill")
                            .font(.system(size: 46))

                        VStack(spacing: 6) {
                            Text("SHINN CHEAT")
                                .font(.system(size: 32, weight: .black, design: .rounded))
                                .tracking(-0.8)
                            Text(isVI ? "Nhập key để sử dụng app" : "Enter a key to use the app")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.top, 40)

                    VStack(alignment: .leading, spacing: 12) {
                        Label(isVI ? "Key kích hoạt" : "Activation key", systemImage: "lock.fill")
                            .font(.headline)

                        TextField(isVI ? "Dán key vào đây" : "Paste your key", text: $keyText)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .focused($focused)
                            .padding(14)
                            .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .disabled(license.isBusy)
                            .onSubmit { Task { await submit() } }

                        if let error = license.lastError, !error.isEmpty {
                            Text(error)
                                .font(.footnote.bold())
                                .foregroundStyle(.red)
                        }

                        Button(action: { Task { await submit() } }) {
                            HStack {
                                if license.isBusy {
                                    ProgressView()
                                        .tint(Color(.systemBackground))
                                }
                                Text(isVI ? "Kích hoạt" : "Activate")
                                    .font(.system(size: 15, weight: .bold))
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 13)
                            .background(Color.primary, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .foregroundStyle(Color(.systemBackground))
                        }
                        .buttonStyle(.plain)
                        .disabled(license.isBusy)
                    }
                    .padding(16)
                    .shinnGlass()
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .onAppear {
            DispatchQueue.main.async { focused = true }
        }
    }

    private func submit() async {
        let ok = await license.activate(key: keyText, language: settings.language)
        guard ok else { return }

        if let raw = license.boundRole,
           let role = UserRole(rawValue: raw.lowercased()) {
            session.role = role
        } else {
            session.role = .member
        }
    }
}

struct ContentView: View {
    @StateObject var session = Session()
    @StateObject private var license = LicenseManager()
    @State private var path: [Route] = []

    var body: some View {
        Group {
            if !license.isActivated {
                ActivateKeyView()
            } else if session.role == nil {
                RoleGateView()
            } else {
                NavigationStack(path: $path) {
                    HomeView(open: { path.append($0) })
                        .navigationDestination(for: Route.self) { route in
                            switch route {
                            case .packages(let category):
                                PackagesView(initialCategory: category)
                            case .detail(let id):
                                PackageDetailView(packageID: id)
                            case .settings:
                                SettingsView()
                            case .about:
                                AboutView()
                            case .support:
                                SupportView()
                            }
                        }
                }
                .tint(.primary)
            }
        }
        .environmentObject(session)
        .environmentObject(license)
        .onAppear {
            if license.isActivated,
               let raw = license.boundRole,
               let role = UserRole(rawValue: raw.lowercased()) {
                session.role = role
            }
        }
        .animation(.easeInOut(duration: 0.25), value: session.role)
        .animation(.easeInOut(duration: 0.25), value: license.isActivated)
    }
}