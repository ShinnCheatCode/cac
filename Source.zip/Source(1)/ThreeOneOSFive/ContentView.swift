// FILE: ThreeOneOSFive/ContentView.swift

import SwiftUI
import UIKit

enum LicenseConfig {
    static let validateURL = URL(string: "https://<project-ref>.supabase.co/rest/v1/rpc/validate_license")!
    static let supabaseAnonKey = "<your-anon-key>"
    static let storageKey = "shinn.license.key"
    static let activatedKey = "shinn.license.activated"
    static let deviceIDKey = "shinn.device.id"
}

struct LicenseRequest: Codable {
    let license_key: String
    let device_id: String
}

struct LicenseResponse: Codable {
    let valid: Bool
    let message: String?
    let expires_at: String?
}

enum LicenseError: LocalizedError {
    case invalidURL
    case network(String)
    case invalidKey(String)
    case server(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Đường dẫn máy chủ không hợp lệ."
        case .network(let m):
            return "Lỗi kết nối: \(m)"
        case .invalidKey(let m):
            return m.isEmpty ? "Key không hợp lệ." : m
        case .server(let m):
            return "Lỗi máy chủ: \(m)"
        }
    }
}

final class LicenseService {
    static let shared = LicenseService()

    private var deviceID: String {
        if let id = UserDefaults.standard.string(forKey: LicenseConfig.deviceIDKey) {
            return id
        }
        let newID = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        UserDefaults.standard.set(newID, forKey: LicenseConfig.deviceIDKey)
        return newID
    }

    func validate(key: String, completion: @escaping (Result<LicenseResponse, LicenseError>) -> Void) {
        let cleanKey = key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !cleanKey.isEmpty else {
            completion(.failure(.invalidKey("Vui lòng nhập key.")))
            return
        }

        var request = URLRequest(url: LicenseConfig.validateURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(LicenseConfig.supabaseAnonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(LicenseConfig.supabaseAnonKey)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = 20

        let body = LicenseRequest(license_key: cleanKey, device_id: deviceID)
        request.httpBody = try? JSONEncoder().encode(body)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(.network(error.localizedDescription)))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(.server("Không có phản hồi.")))
                return
            }
            guard let data = data else {
                completion(.failure(.server("Không có dữ liệu.")))
                return
            }

            do {
                let decoded = try JSONDecoder().decode(LicenseResponse.self, from: data)
                if decoded.valid {
                    completion(.success(decoded))
                } else {
                    completion(.failure(.invalidKey(decoded.message ?? "")))
                }
            } catch {
                let text = String(data: data, encoding: .utf8) ?? ""
                if http.statusCode == 200, text.lowercased().contains("true") {
                    completion(.success(LicenseResponse(valid: true, message: nil, expires_at: nil)))
                } else {
                    completion(.failure(.server("HTTP \(http.statusCode)")))
                }
            }
        }.resume()
    }

    func saveActivation(key: String) {
        UserDefaults.standard.set(key, forKey: LicenseConfig.storageKey)
        UserDefaults.standard.set(true, forKey: LicenseConfig.activatedKey)
    }

    func isActivated() -> Bool {
        UserDefaults.standard.bool(forKey: LicenseConfig.activatedKey)
    }

    func deactivate() {
        UserDefaults.standard.removeObject(forKey: LicenseConfig.storageKey)
        UserDefaults.standard.set(false, forKey: LicenseConfig.activatedKey)
    }
}

struct KeyActivationView: View {
    @State private var keyInput: String = ""
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?
    @FocusState private var focused: Bool

    let onActivated: () -> Void

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 26) {
                    Spacer(minLength: 40)

                    Image(systemName: "key.fill")
                        .font(.system(size: 64, weight: .regular))
                        .foregroundColor(.white)

                    VStack(spacing: 6) {
                        Text("SHINN CHEAT")
                            .font(.system(size: 34, weight: .black, design: .rounded))
                            .foregroundColor(.white)
                        Text("Nhập key để sử dụng app")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                    }

                    VStack(alignment: .leading, spacing: 14) {
                        Label("Key kích hoạt", systemImage: "lock.fill")
                            .font(.headline)
                            .foregroundColor(.white)

                        TextField("Dán key vào đây", text: $keyInput)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .keyboardType(.asciiCapable)
                            .focused($focused)
                            .padding(14)
                            .background(Color(white: 0.13))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.white.opacity(0.15), lineWidth: 1)
                            )
                            .onSubmit { activate() }

                        if let errorMessage {
                            Text(errorMessage)
                                .font(.footnote)
                                .foregroundColor(.red)
                                .fixedSize(horizontal: false, vertical: true)
                        }

                        Button(action: activate) {
                            HStack(spacing: 8) {
                                if isLoading {
                                    ProgressView().tint(.black)
                                }
                                Text(isLoading ? "Đang kiểm tra…" : "Kích hoạt")
                                    .font(.system(size: 17, weight: .semibold))
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(Color.white)
                            .foregroundColor(.black)
                            .cornerRadius(12)
                        }
                        .disabled(isLoading || keyInput.trimmingCharacters(in: .whitespaces).isEmpty)
                        .opacity(isLoading || keyInput.trimmingCharacters(in: .whitespaces).isEmpty ? 0.5 : 1)
                    }
                    .padding(20)
                    .background(Color(white: 0.09))
                    .cornerRadius(16)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.white.opacity(0.08), lineWidth: 1)
                    )
                    .padding(.horizontal, 20)

                    Spacer(minLength: 40)
                }
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .onAppear {
            if !keyInput.isEmpty { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                focused = true
            }
        }
        .onChange(of: keyInput) { _ in
            if errorMessage != nil { errorMessage = nil }
        }
    }

    private func activate() {
        guard !isLoading else { return }
        isLoading = true
        errorMessage = nil
        focused = false

        LicenseService.shared.validate(key: keyInput) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success:
                    LicenseService.shared.saveActivation(
                        key: keyInput.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
                    )
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        onActivated()
                    }
                case .failure(let error):
                    errorMessage = error.errorDescription
                }
            }
        }
    }
}

struct ContentView: View {
    @State private var activated: Bool = LicenseService.shared.isActivated()

    var body: some View {
        Group {
            if activated {
                MainAppView()
            } else {
                KeyActivationView {
                    activated = true
                }
            }
        }
        .animation(.easeInOut(duration: 0.25), value: activated)
    }
}

struct MainAppView: View {
    @StateObject private var settings = AppSettings()
    @StateObject private var store = RepoStore()
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()

    var body: some View {
        HomeView(open: { _ in })
            .environmentObject(settings)
            .environmentObject(store)
            .environmentObject(appState)
            .environmentObject(patchDraftCoordinator)
            .environmentObject(fileOperationCoordinator)
            .preferredColorScheme(settings.theme.colorScheme)
            .task {
                await store.bootstrap(autoRefresh: settings.autoRefresh)
                appState.detectSupport()
            }
            .onOpenURL { url in
                patchDraftCoordinator.presentImport(url)
            }
    }
}