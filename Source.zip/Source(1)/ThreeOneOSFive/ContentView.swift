

i import SwiftUI

// MARK: - App Entry Point
@main
struct ShinnCheatApp: App {
    @StateObject private var repoStore = RepoStore()
    @StateObject private var authManager = LicenseManager()
    
    var body: some Scene {
        WindowGroup {
            MainContainerView()
                .environmentObject(repoStore)
                .environmentObject(authManager)
                .preferredColorScheme(.dark)
        }
    }
}

// MARK: - Models & Stores
class RepoStore: ObservableObject {
    @Published var repos: [RepoItem] = [
        RepoItem(name: "Shinn Official Repo", url: "https://repo.shinn.dev", isVerified: true),
        RepoItem(name: "Community Tweaks", url: "https://community.shinn.dev", isVerified: false)
    ]
    @Published var activeTweaks: [String] = ["Speed Hack x2", "Anti-Ban Shield"]
}

struct RepoItem: Identifiable {
    let id = UUID()
    let name: String
    let url: String
    let isVerified: Bool
}

class LicenseManager: ObservableObject {
    @Published var isActivated: Bool = false
    @Published var licenseKey: String = ""
    @Published var errorMessage: String? = nil
    
    func activateLicense(completion: @escaping (Bool) -> Void) {
        // Giả lập kết nối Supabase xác thực key bản quyền
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            if self.licenseKey.uppercased() == "SHINN-2026-VIP" {
                self.isActivated = true
                self.errorMessage = nil
                completion(true)
            } else {
                self.errorMessage = "Mã bản quyền không hợp lệ hoặc đã hết hạn!"
                completion(false)
            }
        }
    }
}

// MARK: - Main Container View
struct MainContainerView: View {
    @EnvironmentObject var authManager: LicenseManager
    @State private var selectedTab = 0
    
    var body: some View {
        ZStack {
            // Background Gradient
            LinearGradient(colors: [Color(#colorLiteral(red: 0.05019607843, green: 0.05019607843, blue: 0.1019607843, alpha: 1)), Color(#colorLiteral(red: 0.1019607843, green: 0.07843137255, blue: 0.2, alpha: 1))], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            
            if authManager.isActivated {
                TabView(selection: $selectedTab) {
                    HomeDashboardView()
                        .tabItem {
                            Label("Trang chủ", systemImage: "house.fill")
                        }
                        .tag(0)
                    
                    RepoManagerView()
                        .tabItem {
                            Label("Kho lưu trữ", systemImage: "archivebox.fill")
                        }
                        .tag(1)
                    
                    SettingsView()
                        .tabItem {
                            Label("Cài đặt", systemImage: "gearshape.fill")
                        }
                        .tag(2)
                }
                .accentColor(.cyan)
            } else {
                LicenseActivationView()
            }
        }
    }
}

// MARK: - License Activation View (Supabase Auth Mock)
struct LicenseActivationView: View {
    @EnvironmentObject var authManager: LicenseManager
    @State private var isLoading = false
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "shield.lefthalf.filled")
                .font(.system(size: 70))
                .foregroundStyle(.cyan, .indigo)
                .shadow(color: .cyan.opacity(0.5), radius: 10, x: 0, y: 0)
            
            Text("Xác Thực Bản Quyền")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            Text("Vui lòng nhập mã bản quyền kết nối Supabase để tiếp tục sử dụng Shinn Cheat.")
                .font(.subheadline)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 30)
            
            VStack(alignment: .leading, spacing: 8) {
                SecureField("Nhập License Key...", text: $authManager.licenseKey)
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding()
                    .background(Color.white.opacity(0.08))
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                    )
                    .foregroundColor(.white)
                
                if let error = authManager.errorMessage {
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.red)
                }
            }
            .padding(.horizontal, 30)
            
            Button(action: {
                isLoading = true
                authManager.activateLicense { _ in
                    isLoading = false
                }
            }) {
                HStack {
                    if isLoading {
                        ProgressView()
                            .tint(.white)
                    } else {
                        Text("Kích Hoạt Ngay")
                            .fontWeight(.semibold)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(LinearGradient(colors: [.cyan, .blue], startPoint: .leading, endPoint: .trailing))
                .foregroundColor(.white)
                .cornerRadius(12)
                .shadow(color: .cyan.opacity(0.3), radius: 8, x: 0, y: 4)
            }
            .padding(.horizontal, 30)
            .disabled(isLoading)
        }
        .padding()
        .glassCard()
        .padding(20)
    }
}

// MARK: - Home Dashboard View
struct HomeDashboardView: View {
    @EnvironmentObject var repoStore: RepoStore
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.clear.ignoresSafeArea()
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // Status Card Glassmorphism
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Circle()
                                    .fill(Color.green)
                                    .frame(width: 10, height: 10)
                                Text("Hệ thống hoạt động ổn định")
                                    .font(.caption)
                                    .foregroundColor(.green)
                                Spacer()
                                Text("v2.6.0")
                                    .font(.caption2)
                                    .foregroundColor(.gray)
                            }
                            
                            Text("Shinn Cheat Hub")
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            
                            Text("Đã kích hoạt các tính năng tăng tốc và mod an toàn.")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .glassCard()
                        
                        // Active Tweaks Section
                        Text("Tính năng đang bật")
                            .font(.headline)
                            .foregroundColor(.white)
                        
                        ForEach(repoStore.activeTweaks, id: \.self) { tweak in
                            HStack {
                                Image(systemName: "checkmark.shield.fill")
                                    .foregroundColor(.cyan)
                                Text(tweak)
                                    .foregroundColor(.white)
                                    .fontWeight(.medium)
                                Spacer()
                                Toggle("", isOn: .constant(true))
                                    .labelsHidden()
                                    .tint(.cyan)
                            }
                            .padding()
                            .glassCard()
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Trang chủ")
            .navigationBarHidden(true)
        }
    }
}

// MARK: - Repo Manager View
struct RepoManagerView: View {
    @EnvironmentObject var repoStore: RepoStore
    @State private var newRepoUrl: String = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.clear.ignoresSafeArea()
                
                List {
                    Section(header: Text("Thêm Kho Gói Mới").foregroundColor(.cyan)) {
                        HStack {
                            TextField("https://repo...", text: $newRepoUrl)
                                .textFieldStyle(PlainTextFieldStyle())
                                .foregroundColor(.white)
                            Button(action: {
                                if !newRepoUrl.isEmpty {
                                    repoStore.repos.append(RepoItem(name: "Custom Repo", url: newRepoUrl, isVerified: false))
                                    newRepoUrl = ""
                                }
                            }) {
                                Text("Thêm")
                                    .fontWeight(.bold)
                                    .foregroundColor(.cyan)
                            }
                        }
                    }
                    .listRowBackground(Color.white.opacity(0.05))
                    
                    Section(header: Text("Danh Sách Kho Gói").foregroundColor(.cyan)) {
                        ForEach(repoStore.repos) { repo in
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(repo.name)
                                        .font(.headline)
                                        .foregroundColor(.white)
                                    if repo.isVerified {
                                        Image(systemName: "checkmark.seal.fill")
                                            .foregroundColor(.cyan)
                                    }
                                    Spacer()
                                }
                                Text(repo.url)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }
                            .padding(.vertical, 4)
                        }
                        .listRowBackground(Color.white.opacity(0.05))
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Kho lưu trữ")
        }
    }
}

// MARK: - Settings View
struct SettingsView: View {
    @EnvironmentObject var authManager: LicenseManager
    @AppStorage("isDarkMode") private var isDarkMode = true
    @AppStorage("selectedLanguage") private var selectedLanguage = "Việt Nam"
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.clear.ignoresSafeArea()
                
                Form {
                    Section(header: Text("Cài đặt chung").foregroundColor(.cyan)) {
                        Picker("Ngôn ngữ", selection: $selectedLanguage) {
                            Text("Tiếng Việt").tag("Việt Nam")
                            Text("English").tag("English")
                        }
                        .foregroundColor(.white)
                        
                        Toggle("Chế độ tối", isOn: $isDarkMode)
                            .tint(.cyan)
                    }
                    .listRowBackground(Color.white.opacity(0.05))
                    
                    Section(header: Text("Tài khoản & Bản quyền").foregroundColor(.cyan)) {
                        HStack {
                            Text("Trạng thái")
                            Spacer()
                            Text(authManager.isActivated ? "Đã kích hoạt" : "Chưa kích hoạt")
                                .foregroundColor(authManager.isActivated ? .green : .red)
                        }
                        
                        Button(action: {
                            authManager.isActivated = false
                            authManager.licenseKey = ""
                        }) {
                            Text("Đăng xuất / Đổi Key")
                                .foregroundColor(.red)
                        }
                    }
                    .listRowBackground(Color.white.opacity(0.05))
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Cài đặt")
        }
    }
}

// MARK: - Glassmorphism UI Modifier
extension View {
    func glassCard() -> some View {
        self
            .background(.ultraThinMaterial)
            .cornerRadius(16)
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.white.opacity(0.15), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.3), radius: 10, x: 0, y: 5)
    }
}
